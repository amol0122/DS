1.Download the Hadoop native libraries for Windows from the following GitHub repository: 	https://github.com/cdarlint/winutils

	Choose the appropriate Hadoop version (e.g., hadoop-3.3.1) and download the entire folder.

2.Create a new folder named hadoop in your C: drive (e.g., C:\hadoop).

3.Copy the downloaded folder (e.g., hadoop-3.3.1) to the hadoop directory you created in step 2 (e.g., C:\hadoop	\hadoop-3.3.1).

4.Set the HADOOP_HOME environment variable:

	In the "Environment Variables" window, click on the "New" button under "System variables."
	Set the "Variable name" to HADOOP_HOME.
	Set the "Variable value" to the path of the Hadoop folder you copied in step 3 (e.g., C:\hadoop\hadoop-3.3.1).
	Click "OK" to save the changes.

5.Add the Hadoop bin directory to the Path environment variable, if you haven't done so already:
	In the "Environment Variables" window, find the "Path" variable under "System variables."
	Click on the "Edit" button.
	Add the path to the Hadoop bin directory (e.g., C:\hadoop\hadoop-3.3.1\bin) to the "Path" variable.
	Click "OK" to save the changes.
	Restart your terminal (or command prompt) and run the program again using sbt run.