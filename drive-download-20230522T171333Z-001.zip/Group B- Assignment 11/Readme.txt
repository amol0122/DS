1. Install Java11 from chrome

2. install sbt1.8.2 from chrome(https://www.scala-sbt.org/download.html)

3. Install Hadoop (refer hadoop.readme)

4.You should run the sbt run command in the root directory of your Scala project, where the build.sbt file is 	located.

	For example, if you followed the instructions in the previous answer to create a simple Apache Spark program 	in Scala, your project directory structure should look like this:

	spark-wordcount/
	├── build.sbt
	├── input.txt
	└── src/
    	└── main/
        	└── scala/
            	└── WordCount.scala


5.In this case, you should open a terminal (or command prompt) and navigate to the spark-wordcount directory:

	$ cd /path/to/spark-wordcount

Then, run the sbt run command:

	$ sbt run

This command will compile and run your Scala program using the sbt build tool. Make sure you are in the correct directory containing the build.sbt file before running the command.