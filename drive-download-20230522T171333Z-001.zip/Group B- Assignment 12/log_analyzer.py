from collections import defaultdict


def map_function(line):
    # Split the line into words
    words = line.split()

    # Extract the log level (the second word in the line)
    log_level = words[2]

    # Emit the log level as the key and the value 1 as the value
    return (log_level, 1)

# Define the Reduce function
def reduce_function(log_level, values):
    # Calculate the sum of the values
    count = sum(values)

    # Emit the log level and the count
    return (log_level, count)


# Implement the MapReduce job
def main(input_file):
    # Read the input log file
    with open(input_file, 'r') as f:
        lines = f.readlines()

    # Apply the Map function to each line
    map_results = [map_function(line) for line in lines]

    # Group the intermediate results by key (log level)
    grouped_results = defaultdict(list)
    for key, value in map_results:
        grouped_results[key].append(value)

    # Apply the Reduce function to each group
    reduce_results = [reduce_function(key, values) for key, values in grouped_results.items()]

    # Print the results
    for log_level, count in reduce_results:
        print(f"{log_level}: {count}")


# Run the MapReduce job
if __name__ == "__main__":
    input_file = "sample_log.txt"  # Replace this with the path to your input log file
    main(input_file)
