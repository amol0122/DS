import random
import datetime
from pathlib import Path

def generate_log_entry(current_time):
    log_levels = ['INFO', 'WARNING', 'ERROR']
    messages = {
        'INFO': ['Starting the application', 'User logged in', 'File uploaded'],
        'WARNING': ['Low disk space', 'High memory usage', 'Slow response time'],
        'ERROR': ['Failed to connect to the database', 'File not found', 'Access denied']
    }

    # Choose a random log level
    log_level = random.choice(log_levels)

    # Choose a random message for the selected log level
    message = random.choice(messages[log_level])

    # Create a log entry with the current time, log level, and message
    log_entry = f"{current_time} {log_level} {message}\n"

    return log_entry

def generate_log_file(file_path, num_entries):
    start_time = datetime.datetime.now()

    with open(file_path, 'w') as f:
        for i in range(num_entries):
            current_time = start_time + datetime.timedelta(seconds=i)
            log_entry = generate_log_entry(current_time)
            f.write(log_entry)

if __name__ == "__main__":
    file_path = Path("sample_log.txt")
    num_entries = 100

    generate_log_file(file_path, num_entries)
    print(f"Generated {num_entries} log entries in {file_path}")